#define HAVE_THREAD_SAFETY_ATTRIBUTES
#include "../src/mutex.h"

int main() {}
